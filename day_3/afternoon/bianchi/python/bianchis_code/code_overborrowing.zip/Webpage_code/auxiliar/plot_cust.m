LineColor_d='r';
% LineWidth_p=4 
LineW_p=3;

LineColor_p='b';
% LineWidth_d=2 
LineW_d=3;

LineW=LineW_d;
LineColor=LineColor_d;

col1=[0.756862759590149 0.866666674613953 0.776470601558685];
col2=[0.501960813999176 0.501960813999176 0.501960813999176];
col3=[0.0431372560560703 0.517647087574005 0.780392169952393];
  
lineW_p=2;
lineW_d=3.5;
lineW_q=2.5;

col_sp = [0 .5 .6];
col_de = [.8 0 0];

LineStyle_d='-';
LineStyle_p='--';
% figure
% H=plot(1:1:10)
% set(H,'Color',col_de,'Linewidth',LineW_d)
% hXlabel=xlabel('bonds')
% hTitle=title('bonds')
% set(gca,'FontSize',13,'FontName','Times New Roman')
% hold on
% H=plot(2:1:11)
% set(H,'Color',col_de,'Linewidth',LineW_d)
% set(gca,  'Box'         , 'off'     , 'TickDir'     , 'out'     ,'TickLength'  , [.02 .02] , 'YMinorTick'  , 'off     ' , 'YGrid'  ....
%   , 'off'      , 'XColor'      , [.3 .3 .3],    'YColor'      , [.3 .3 .3],    'LineWidth'   , 1      )  ,...
% set(hTitle,'Fontsize',20,'FontName'   , 'AvantGarde')
% set(hXlabel,'Fontsize',20,'FontName'   , 'AvantGarde')