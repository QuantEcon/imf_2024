LineColor_d='r';
LineW_p=3;
LineColor_p='b';
LineW_d=3;

LineW=LineW_d;
LineColor=LineColor_d;

col1=[0.756862759590149 0.866666674613953 0.776470601558685];
col2=[0.501960813999176 0.501960813999176 0.501960813999176];
col3=[0.0431372560560703 0.517647087574005 0.780392169952393];
  
lineW_p=2;
lineW_d=3.5;
lineW_q=2.5;

col_sp = [0 .5 .6];
col_de = [.8 0 0];


col_1T = [.1 .1 .1];


LineStyle_d='-';
LineStyle_p='--';
 