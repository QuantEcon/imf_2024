figure
subplot(1,3,1)
plot(B,c','o'); title('c')
subplot(1,3,2)
plot(B,bp); title('bond policy')
subplot(1,3,3)
plot(B,price); title('pn')
 